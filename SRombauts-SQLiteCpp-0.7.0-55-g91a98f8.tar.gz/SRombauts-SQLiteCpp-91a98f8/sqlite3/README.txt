"sqlite3.c" and "sqlite3.h" files from sqlite-amalgamation-3071401.zip (SQLite 3.7.14.1)

Those files are provided for easy setup under Windows ; they are used by the Visual Studio example solution.

They are not used by the Linux Makefile, which thus requires the Linux "libsqlite3-dev" package.
